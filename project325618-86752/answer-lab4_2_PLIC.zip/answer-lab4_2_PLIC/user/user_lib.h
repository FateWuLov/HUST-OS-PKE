/*
 * header file to be used by applications.
 */

int printu(const char *s, ...);
int exit(int code);
int fork();
int sleep();
int uartgetchar();
int gpio_reg_write(char val);
answer to PKE lab4_2_PLIC (lab4_2_PLIC branch).

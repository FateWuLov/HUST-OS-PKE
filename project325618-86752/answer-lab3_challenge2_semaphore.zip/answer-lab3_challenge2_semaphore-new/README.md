answer to PKE lab3 challenge2 (lab3_challenge2_semaphore branch).

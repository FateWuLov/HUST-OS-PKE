answer to PKE lab3 challenge1 (lab3_challenge1_wait branch).

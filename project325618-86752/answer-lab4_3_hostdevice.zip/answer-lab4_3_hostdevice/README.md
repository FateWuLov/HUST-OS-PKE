answer to PKE lab4_3 (lab4_3_hostdevice branch).

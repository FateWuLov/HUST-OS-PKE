#pragma pack(4) // 结构体按4字节对齐
#define _SYS__TIMEVAL_H_ // 覆盖标准库的timeval定义
struct timeval {
    unsigned int tv_sec;
    unsigned int tv_usec;
};

#include "user_lib.h"
#include "videodev2.h"
#define DARK 64
#define RATIO 7 / 10

int main() {
    char *info = allocate_share_page(); // 分配一个共享页，方便父子进程之间传递信息（小车的状态）
    int pid = do_fork();
    if (pid == 0) { // 子进程
        int f = do_open("/dev/video0", O_RDWR), r; // 打开设备文件

        struct v4l2_format fmt;
        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_YUYV;
        fmt.fmt.pix.width = 320;
        fmt.fmt.pix.height = 180;
        fmt.fmt.pix.field = V4L2_FIELD_NONE;
        r = do_ioctl(f, VIDIOC_S_FMT, &fmt); // 设置摄像头：图片大小为320*180，格式为YUYV
        printu("Pass format: %d\n", r);

        struct v4l2_requestbuffers req;
        req.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        req.count = 1; req.memory = V4L2_MEMORY_MMAP;
        r = do_ioctl(f, VIDIOC_REQBUFS, &req); // 设置摄像头：使用mmap方式读取数据，缓冲区数量为1
        printu("Pass request: %d\n", r);

        struct v4l2_buffer buf;
        buf.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        buf.memory = V4L2_MEMORY_MMAP; buf.index = 0;
        r = do_ioctl(f, VIDIOC_QUERYBUF, &buf); // 设置buf结构体对应的缓冲区索引
        printu("Pass buffer: %d\n", r);

        int length = buf.length;
        char *img = do_mmap(NULL, length, PROT_READ | PROT_WRITE, MAP_SHARED, f, buf.m.offset); // mmap映射内存
        unsigned int type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        r = do_ioctl(f, VIDIOC_STREAMON, &type); // 开启摄像头
        printu("Open stream: %d\n", r);

        char *img_data = allocate_page(); // 分配内存，用来保存图片
        for (int i = 0; i < (length + 4095) / 4096 - 1; i++)
            allocate_page(); // 图片较大，需分配更多的页
        yield(); // 初始化完设备了，让主进程开始监听蓝牙

        for (;;) {
            if (*info == '1') { // 小车处于前进状态
                r = do_ioctl(f, VIDIOC_QBUF, &buf); // 缓冲入队
                printu("Buffer enqueue: %d\n", r);
                r = do_ioctl(f, VIDIOC_DQBUF, &buf); // 缓冲出队，这时拍摄完一张照片
                printu("Buffer dequeue: %d\n", r);
                r = read_mmap(img_data, img, length); // 把照片从PS端的映射内存读出来
                int num = 0;
                for (int i = 0; i < length; i += 2)
                    if (img_data[i] < DARK) num++; // 统计灰度小于DARK的像素数量
                printu("Dark num: %d > %d\n", num, length / 2 * RATIO);
                if (num > length / 2 * RATIO) { // 如果灰度小于DARK的像素数量大于像素总数的RATIO比例（注意length是yuyv图片数据的总大小，像素总数是该大小的一半）
                    *info = '0'; gpio_reg_write(0x00); // 刹车
                }
            } else if (*info == 'q') break;
        }

        for (char *i = img_data; i - img_data < length; i += 4096)
            free_page(i); // 释放内存
        r = do_ioctl(f, VIDIOC_STREAMOFF, &type); // 关闭摄像头
        printu("Close stream: %d\n", r);
        do_munmap(img, length); do_close(f); exit(0); // 关闭文件和解映射
    } else { // 主进程
        yield(); // 先让子进程初始化完摄像头
        for (;;) {
            char temp = (char)uartgetchar(); // 接受蓝牙信号
            printu("From bluetooth: %c\n", temp);
            *info = temp;
            switch (temp) {
                case '1': gpio_reg_write(0x2e); break; //前进
                case '2': gpio_reg_write(0xd1); break; //后退
                case '3': gpio_reg_write(0x63); break; //左转
                case '4': gpio_reg_write(0x9c); break; //右转
                case 'q': exit(0); break;
                default: gpio_reg_write(0x00); break;  //停止
            }
        }
    }
    return 0;
}

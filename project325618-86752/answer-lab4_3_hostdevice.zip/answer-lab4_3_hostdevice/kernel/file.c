#include "pmm.h"
#include "riscv.h"
#include "process.h"
#include "util/functions.h"
#include "spike_interface/spike_file.h"
#include "spike_interface/spike_utils.h"

#define MMAP_MEM_SIZE 2
typedef struct {
    uint64 addr, length, num;
} mmap_t;
mmap_t mmap_mem[MMAP_MEM_SIZE];

int read_mmap(char *addr, int length, char *buf) {
    for (int i = 0; i < MMAP_MEM_SIZE; i++) {
        if ((uint64)addr >= mmap_mem[i].addr
                && length <= mmap_mem[i].length) { // 待获取的地址区间包含在映射的地址区间之中
            return frontend_syscall(HTIFSYS_readmmap, mmap_mem[i].num,
                    (uint64)addr - mmap_mem[i].addr, length,
                    (uint64)buf, 0, 0, 0);
        }
    }
    return -1;
}
int do_open(char *pathname, int flags) {
    spike_file_t *f = spike_file_open(pathname, flags, 0);
    if ((int64)f < 0) return -1; else {
        int fd = spike_file_dup(f);
        if (fd < 0) {
            spike_file_decref(f); return -1;
        } else return fd;
    }
}
int do_write(int fd, char *buf, uint64 count) {
    spike_file_t *f = spike_file_get(fd);
    return spike_file_write(f, buf, count);
    // char *space = (char *)alloc_page();
    // for (uint64 i = 0; i < count; i += PGSIZE) {
    //     uint64 len = PGSIZE < count - i ? PGSIZE : count - i;
    //     read_mmap(buf + i, len, space);
    //     if (spike_file_write(f, space, len) < len) {
    //         free_page(space); return i + len;
    //     }
    // }
    // free_page(space); return count;
}
int do_close(int fd) {
    spike_file_t *f = spike_file_get(fd);
    return spike_file_close(f);
}
int do_ioctl(int fd, uint64 request, char *data) {
    return frontend_syscall(HTIFSYS_ioctl, spike_file_get(fd)->kfd,
            request, (uint64)data, 0, 0, 0, 0);
}
char *do_mmap(char *addr, uint64 length, int prot, int flags, int fd, int64 offset) {
    for (int i = 0; i < MMAP_MEM_SIZE; i++) {
        if (mmap_mem[i].length == 0) { // 找到一个还没有用过的数组元素
            int64 r = frontend_syscall(HTIFSYS_mmap, (uint64)addr, length,
                    prot, flags, spike_file_get(fd)->kfd, offset, 0);
            if (r >= 0) {
                mmap_mem[i].addr = g_ufree_page; // 申请虚拟地址并保存，PKE用的虚拟地址管理策略非常简单，即用一个g_ufree_page变量表示下一个空闲的虚拟页的地址
                g_ufree_page += ROUNDUP(length, PGSIZE); // 更新g_ufree_page变量，这个变量需要按PGSIZE（4096）字节对齐，所以需要向上取整
                mmap_mem[i].length = length; // 保存映射的内存长度
                mmap_mem[i].num = r; // 保存返回的数组索引
                return (char *)mmap_mem[i].addr; // 返回申请的虚拟地址
            } else return (char *)-1;
        }
    }
    return (char *)-1;
}
int do_munmap(char *addr, uint64 length) {
    for (int i = 0; i < MMAP_MEM_SIZE; i++) {
        if (mmap_mem[i].addr == (uint64)addr
                && mmap_mem[i].length == length) { // 找到对应的数组元素
            int64 r = frontend_syscall(HTIFSYS_munmap, mmap_mem[i].num, length, 0, 0, 0, 0, 0);
            if (r >= 0) mmap_mem[i].length = 0; // 表示“还没有用过”
            return r;
        }
    }
    return -1;
}

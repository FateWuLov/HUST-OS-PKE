#ifndef _SPIKE_MEMORY_H_
#define _SPIKE_MEMORY_H_

#include "util/types.h"
void query_mem(uint64 fdt);

#endif

/*
 * header file to be used by applications.
 */

int printu(const char *s, ...);
int exit(int code);

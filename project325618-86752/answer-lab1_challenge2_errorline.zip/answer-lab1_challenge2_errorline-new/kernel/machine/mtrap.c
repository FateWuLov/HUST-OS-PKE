#include "kernel/riscv.h"
#include "kernel/process.h"
#include "spike_interface/spike_utils.h"
#include "util/string.h"

static void handle_instruction_access_fault() { panic("Instruction access fault!"); }

static void handle_load_access_fault() { panic("Load access fault!"); }

static void handle_store_access_fault() { panic("Store/AMO access fault!"); }

static void handle_illegal_instruction() { panic("Illegal instruction!"); }

static void handle_misaligned_load() { panic("Misaligned Load!"); }

static void handle_misaligned_store() { panic("Misaligned AMO!"); }

static void handle_timer() {
  int cpuid = 0;
  // setup the timer fired at next time (TIMER_INTERVAL from now)
  *(uint64*)CLINT_MTIMECMP(cpuid) = *(uint64*)CLINT_MTIMECMP(cpuid) + TIMER_INTERVAL;

  // setup a soft interrupt in sip (S-mode Interrupt Pending) to be handled in S-mode
  write_csr(sip, SIP_SSIP);
}

char path[128], code[10240]; struct stat mystat;
//
// Parameter is the entry of array "process->line".
// The function prints the code line the entry points to.
//
void line_print(addr_line *line) {
    int l = strlen(current->dir[current->file[line->file].dir]);
    // concat the directory and file to construct path
    strcpy(path, current->dir[current->file[line->file].dir]);
    path[l] = '/';
    strcpy(path + l + 1, current->file[line->file].file);
    // sprint(path);
    
    // read the code line and print
    spike_file_t *f = spike_file_open(path, O_RDONLY, 0);
    spike_file_stat(f, &mystat); spike_file_read(f, code, mystat.st_size);
    spike_file_close(f); int off = 0, cnt = 0;
    while (off < mystat.st_size) {
        int x = off; while (x < mystat.st_size && code[x] != '\n') x++;
        if (cnt == line->line - 1) {
            code[x] = '\0';
            sprint("Runtime error at %s:%d\n%s\n", path, line->line, code + off);
            break;
        } else cnt++, off = x + 1;
    }
}
//
// Find the "process->line" array entry according to
// the exception intrustion address stores in epc register.
//
void error_print() {
    uint64 mepc = read_csr(mepc);
    for (int i = 0; i < current->line_ind; i++) {
        // find the exception line table entry
        if (mepc < current->line[i].addr) {
            line_print(current->line + i - 1); break;
        }
    }
}

//
// handle_mtrap calls cooresponding functions to handle an exception of a given type.
//
void handle_mtrap() {
  uint64 mcause = read_csr(mcause);
  switch (mcause) {
    case CAUSE_MTIMER:
      handle_timer();
      break;
    case CAUSE_FETCH_ACCESS:
      error_print();
      handle_instruction_access_fault();
      break;
    case CAUSE_LOAD_ACCESS:
      error_print();
      handle_load_access_fault();
    case CAUSE_STORE_ACCESS:
      error_print();
      handle_store_access_fault();
      break;
    case CAUSE_ILLEGAL_INSTRUCTION:
      // TODO (lab1_2): call handle_illegal_instruction to implement illegal instruction
      // interception, and finish lab1_2.
      error_print();
      handle_illegal_instruction();

      break;
    case CAUSE_MISALIGNED_LOAD:
      error_print();
      handle_misaligned_load();
      break;
    case CAUSE_MISALIGNED_STORE:
      error_print();
      handle_misaligned_store();
      break;

    default:
      sprint("machine trap(): unexpected mscause %p\n", mcause);
      sprint("            mepc=%p mtval=%p\n", read_csr(mepc), read_csr(mtval));
      panic( "unexpected exception happened in M-mode.\n" );
      break;
  }
}


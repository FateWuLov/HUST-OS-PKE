answer to PKE lab1 challenge2 (lab1_challenge2_errorline branch).

answer to PKE lab4_1 (lab4_1_polling branch).
